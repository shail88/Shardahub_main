/**
 * ShardaHub Games Module — v2.0
 * Fetches game products dynamically from Supabase and renders them
 * with their full tier buttons including "View Details" → product.html
 */

const GameModule = {
    allGames: [],

    init() {
        console.log('🎮 Game Module Initialized');
        this.loadGames();
    },

    async loadGames() {
        const grid = document.getElementById('games-grid') || document.getElementById('gamesGrid');
        if (!grid) return;

        grid.innerHTML = `<div class="col-12 text-center py-5">
            <div class="spinner-border text-info" role="status"></div>
            <p class="text-secondary mt-2 small">Loading games...</p>
        </div>`;

        try {
            // Fetch directly — most reliable method
            const { data: games } = await supabase
                .from('products')
                .select('*, product_tiers(*)')
                .eq('product_type', 'game')
                .eq('is_active', true)
                .order('is_featured', { ascending: false });

            this.allGames = games || [];

            if (this.allGames.length > 0) {
                grid.innerHTML = this.allGames.map(g => this.renderGameCard(g)).join('');
                this.renderTierLegend();
            } else {
                grid.innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="bi bi-controller display-1 text-secondary opacity-25 d-block mb-3"></i>
                    <h5 class="text-white fw-bold">No Games Yet</h5>
                    <p class="text-secondary">Run the master_seed.sql in Supabase, then games will appear here.</p>
                    <a href="../admin/index.html" class="btn btn-outline-info rounded-pill px-4">Add Games in Admin</a>
                </div>`;
            }
        } catch (e) {
            console.error('Games load error:', e);
            grid.innerHTML = `<div class="col-12 text-center py-5 text-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>Failed to load games. Check console.</div>`;
        }
    },

    renderGameCard(game) {
        const tiers = (game.product_tiers || []).sort((a, b) => a.price_inr - b.price_inr);
        const platforms = game.meta_data?.platforms || ['pc', 'web'];
        const platformIcons = { android: 'bi-phone-fill', pc: 'bi-laptop', web: 'bi-globe', ios: 'bi-apple' };

        const tierBtns = tiers.length > 0 ? tiers.map(t => {
            const free = t.price_inr === 0;
            return `
            <button class="btn w-100 btn-sm rounded-3 py-2 fw-medium mb-1"
                    style="background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);"
                    onclick="GameModule.handleGameTier('${game.id}','${game.title.replace(/'/g, "\\'")}','${t.name}',${t.price_inr},'${t.id}')">
                <span class="d-block" style="font-size:0.65rem;color:${free ? '#10b981' : '#0ea5e9'};font-weight:700;">${t.name}</span>
                <span class="text-white fw-bold">${free ? 'Free' : '₹' + t.price_inr.toLocaleString('en-IN')}</span>
            </button>`;
        }).join('') :
            `<button class="btn btn-outline-info w-100 rounded-pill fw-bold"
                onclick="window.location.href='../product.html?id=${game.id}'">
            View Details
        </button>`;

        return `
        <div class="col-md-6 col-lg-4">
            <div class="glass game-card">
                <div class="position-relative overflow-hidden" style="cursor:pointer;"
                     onclick="window.location.href='../product.html?id=${game.id}'">
                    <img src="${game.image_url || 'https://via.placeholder.com/400x200/1a1a3e/8b5cf6?text=' + encodeURIComponent(game.title)}"
                         alt="${game.title}" class="game-thumb w-100" style="height:200px;object-fit:cover;">
                    <div class="position-absolute top-0 start-0 p-2 d-flex gap-1">
                        ${platforms.map(p => `<span class="badge bg-dark bg-opacity-75" style="font-size:0.6rem;">${p}</span>`).join('')}
                    </div>
                    ${game.is_featured ? '<div class="position-absolute top-0 end-0 p-2"><span class="badge" style="background:rgba(245,158,11,0.85);color:#000;font-size:0.65rem;">⭐ FEATURED</span></div>' : ''}
                </div>
                <div class="p-4">
                    <h5 class="fw-bold text-white mb-1">${game.title}</h5>
                    <p class="text-secondary small mb-3" style="height:2.8em;overflow:hidden;">${game.tagline || ''}</p>
                    <div class="d-flex gap-1 mb-3 flex-wrap">
                        ${platforms.map(p => `<i class="bi ${platformIcons[p] || 'bi-device-hdd'} text-secondary" style="font-size:0.8rem;" title="${p}"></i>`).join('')}
                        <span class="text-secondary" style="font-size:0.7rem;">${game.meta_data?.genre || 'Game'}</span>
                    </div>
                    <div class="d-flex flex-column gap-1">${tierBtns}</div>
                    <a href="../product.html?id=${game.id}"
                       class="btn btn-sm btn-outline-secondary w-100 rounded-pill mt-2 border-0 text-secondary"
                       style="font-size:0.8rem;">
                        <i class="bi bi-info-circle me-1"></i>Full Details & License Info
                    </a>
                </div>
            </div>
        </div>`;
    },

    renderTierLegend() {
        const container = document.getElementById('tierExplainedGrid');
        if (!container) return;
        // Already handled in games/index.html static HTML — no override needed
    },

    async handleGameTier(gameId, title, tierName, price, tierId) {
        const user = window.SubpassAuth?.user;
        if (!user) {
            alert('Please login to purchase or play games.');
            window.location.href = '../login.html';
            return;
        }

        if (price === 0) {
            // Free / Demo — grant immediately
            if (typeof ShardaPayments !== 'undefined') {
                ShardaPayments.showToast('Demo access granted! Redirecting...', 'success');
            }
            try {
                await supabase.from('game_licenses').upsert([{
                    user_id: user.id,
                    product_id: gameId,
                    tier_id: tierId,
                    max_downloads: 1
                }], { onConflict: 'user_id,product_id,tier_id' });
            } catch (e) { console.warn('License record error:', e); }
            setTimeout(() => window.location.href = 'dashboard.html', 1200);
            return;
        }

        // Paid — add to cart and go to checkout
        if (typeof ShardaPayments !== 'undefined') {
            ShardaPayments.addToCart({
                id: gameId,
                tierId: tierId,
                name: `${title} — ${tierName}`,
                price: price,
                icon: 'bi-controller',
                category: 'game',
                section: 'game'
            });
            window.location.href = '../checkout.html';
        }
    },

    filterGames(platform) {
        if (!this.allGames) return;
        const filtered = platform === 'all'
            ? this.allGames
            : this.allGames.filter(g => (g.meta_data?.platforms || ['pc', 'web']).includes(platform));

        document.querySelectorAll('[onclick*="filterGames"]').forEach(b => {
            b.classList.remove('active', 'btn-info');
            b.classList.add('btn-outline-secondary');
        });
        event.target.classList.add('active', 'btn-info');
        event.target.classList.remove('btn-outline-secondary');

        const grid = document.getElementById('games-grid') || document.getElementById('gamesGrid');
        if (!grid) return;
        if (filtered.length === 0) {
            grid.innerHTML = `<div class="col-12 text-center py-4 text-secondary">No ${platform} games found.</div>`;
        } else {
            grid.innerHTML = filtered.map(g => this.renderGameCard(g)).join('');
        }
    }
};

// Expose filter function globally (used by inline onclick in HTML)
window.filterGames = (platform) => GameModule.filterGames(platform);

document.addEventListener('DOMContentLoaded', () => {
    new Promise(resolve => {
        if (window.SubpassAuth?.ready) window.SubpassAuth.ready.then(resolve);
        else setTimeout(resolve, 800);
    }).then(() => GameModule.init());
});
